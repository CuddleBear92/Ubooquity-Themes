#! /bin/bash

#Big thanks to Mediabot666 for the argument parsing work!

my_dir=`dirname $0`
usage="Usage: $0 -c 'Comic Name' [-d 'Comic Year'] [-r 'Which result to save']"

while [ "$1" != "" ]; do
    case $1 in
    -c | --comic ) 
        shift
        comicname=$1
        echo Comic: $comicname;;
    -d | --date ) 
        shift 
        date=$1
        echo Date: $date;;
    -r | --result ) 
        shift 
        result=$1
        echo Result: $result;;
    -h | --help ) 
        echo $usage
        exit ;;
    * ) 
        exit 1
esac
shift
done

function getMyImages {
    query="$@"
    [ -z "$query" ] && exit 1  # insufficient arguments
    
    # indicate which search result you would like
    if [ -z "$result" ]; then
        result="1"
    fi
    
    # remove/replace offending characters
    webquery="${query//&/%26}"
    webquery="${webquery//:/%3A}"
    webquery="${webquery// /%20}"   
    query="${query//:/}"
    comicname="${comicname//:/}"

    # set user agent, customize this by visiting http://whatsmyuseragent.com/
    useragent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.89 Safari/537.36'

    # construct google link
    link="www.google.com/search?q='${webquery}'+inurl:series+intitle:Digital&as_sitesearch=www.comixology.com&tbs=iar:s,isz:ex&tbm=isch"

    # fetch link for download
    imagelink=$(wget -e robots=off --user-agent "$useragent" -qO - "$link" | sed 's/\"ou\"/\n\"ou\"/g' | grep '\"ou\"\:\".*\(png\|jpg\|jpeg\).*ow\"' | awk -F'"' '{print $4}' | head -n $result|tail -n1)
    imagelink="${imagelink%\%*}"
    
    # strip resizing info to get larger format
    if [[ $imagelink == *"cmx-images-prod/Series"* ]] ; then
        imagelink=`echo $imagelink | rev | cut -d'.' -f3- | rev`.jpg
    fi

    # construct image link: add 'echo "${google_image}"'
    # after this line for debug output
    if [ -z "$date" ]; then
        google_image="$my_dir/$comicname.jpg"
    else
        google_image="$my_dir/$comicname $date.jpg"
    fi

    # if link comes from the right part of comixology, get actual picture and store in google_image.jpg
    if [[ $imagelink == *"cmx-images-prod/Series"* ]] ; then
    wget --max-redirect 0 -qO "${google_image}" "${imagelink}"
    fi
}

if [ -z "$comicname" ]; then
    echo $usage
    exit 1
else
    echo $"Downloading image"
    getMyImages "$comicname"; 
fi